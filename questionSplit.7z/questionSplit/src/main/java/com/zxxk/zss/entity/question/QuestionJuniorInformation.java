package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 初中信息技术
 */
@Entity(name=Constants.TABLE_QUESTION_JUNIOR_INFORMATION)
public class QuestionJuniorInformation extends Question {

}
