package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 高中英语
 */
@Entity(name=Constants.TABLE_QUESTION_SENIOR_ENGLISH)
public class QuestionSeniorEnglish extends Question {
	

}
