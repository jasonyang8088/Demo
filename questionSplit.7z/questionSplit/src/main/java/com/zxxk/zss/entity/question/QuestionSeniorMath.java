package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 高中数学
 */
@Entity(name=Constants.TABLE_QUESTION_SENIOR_MATH)
public class QuestionSeniorMath extends Question {


}
