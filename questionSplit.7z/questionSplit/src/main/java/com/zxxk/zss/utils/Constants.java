package com.zxxk.zss.utils;

public class Constants {
	
	public final static String TABLE_QUESTION ="question";
	public final static String TABLE_QUESTION_PRIMARY_CHINESE ="question_primary_chinese";
	public final static String TABLE_QUESTION_PRIMARY_ENGLISH ="question_primary_english";
	public final static String TABLE_QUESTION_PRIMARY_INFORMATION ="question_primary_information";
	public final static String TABLE_QUESTION_PRIMARY_MATH ="question_primary_math";
	public final static String TABLE_QUESTION_PRIMARY_MORALITY ="question_primary_morality";
	public final static String TABLE_QUESTION_PRIMARY_SCIENCE ="question_primary_science";
	public final static String TABLE_QUESTION_JUNIOR_CHINESE ="question_junior_chinese";
	public final static String TABLE_QUESTION_JUNIOR_MATH ="question_junior_math";
	public final static String TABLE_QUESTION_JUNIOR_ENGLISH ="question_junior_english";
	public final static String TABLE_QUESTION_JUNIOR_PHYSICS ="question_junior_physics";
	public final static String TABLE_QUESTION_JUNIOR_CHEMISTRY ="question_junior_chemistry";
	public final static String TABLE_QUESTION_JUNIOR_BIOLOGY ="question_junior_biology";
	public final static String TABLE_QUESTION_JUNIOR_HISTORY ="question_junior_history";
	public final static String TABLE_QUESTION_JUNIOR_GEOGRAPHY ="question_junior_geography";
	public final static String TABLE_QUESTION_JUNIOR_POLITICS ="question_junior_politics";
	public final static String TABLE_QUESTION_JUNIOR_SCIENCE ="question_junior_science";
	public final static String TABLE_QUESTION_JUNIOR_INFORMATION ="question_junior_information";
	public final static String TABLE_QUESTION_JUNIOR_COMPREHENSIVE_SCIENCE ="question_junior_comprehensive_science";
	public final static String TABLE_QUESTION_JUNIOR_COMPREHENSIVE_ART ="question_junior_comprehensive_art";
	public final static String TABLE_QUESTION_SENIOR_CHINESE ="question_senior_chinese";
	public final static String TABLE_QUESTION_SENIOR_MATH ="question_senior_math";
	public final static String TABLE_QUESTION_SENIOR_ENGLISH ="question_senior_english";
	public final static String TABLE_QUESTION_SENIOR_PHYSICS ="question_senior_physics";
	public final static String TABLE_QUESTION_SENIOR_CHEMISTRY ="question_senior_chemistry";
	public final static String TABLE_QUESTION_SENIOR_BIOLOGY ="question_senior_biology";
	public final static String TABLE_QUESTION_SENIOR_HISTORY ="question_senior_history";
	public final static String TABLE_QUESTION_SENIOR_GEOGRAPHY ="question_senior_geography";
	public final static String TABLE_QUESTION_SENIOR_POLITICS ="question_senior_politics";
	public final static String TABLE_QUESTION_SENIOR_SCIENCE ="question_senior_science";
	public final static String TABLE_QUESTION_SENIOR_INFORMATION ="question_senior_information";
	public final static String TABLE_QUESTION_SENIOR_COMPREHENSIVE_SCIENCE ="question_senior_comprehensive_science";
	public final static String TABLE_QUESTION_SENIOR_COMPREHENSIVE_ART ="question_senior_comprehensive_art";

}
