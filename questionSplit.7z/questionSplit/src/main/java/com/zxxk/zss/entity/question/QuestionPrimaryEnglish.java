package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 小学英语
 */
@Entity(name=Constants.TABLE_QUESTION_PRIMARY_ENGLISH)
public class QuestionPrimaryEnglish extends Question {
}
