package com.zxxk.zss.dao;

import org.springframework.stereotype.Repository;

import com.zxxk.zss.entity.Question;

@Repository
public class QuestionDAO extends BaseDAO<Question> {

}
