package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 高中文综
 */
@Entity(name=Constants.TABLE_QUESTION_SENIOR_COMPREHENSIVE_ART)
public class QuestionSeniorComprehensiveArt extends Question {


}
