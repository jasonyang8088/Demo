package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 初中理综
 */
@Entity(name=Constants.TABLE_QUESTION_JUNIOR_COMPREHENSIVE_SCIENCE)
public class QuestionJuniorComprehensiveScience extends Question{

}
