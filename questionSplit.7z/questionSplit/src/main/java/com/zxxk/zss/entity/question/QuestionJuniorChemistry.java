package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 初中化学
 */
@Entity(name=Constants.TABLE_QUESTION_JUNIOR_CHEMISTRY)
public class QuestionJuniorChemistry extends Question {

}
