package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 初中科学
 */
@Entity(name=Constants.TABLE_QUESTION_JUNIOR_SCIENCE)
public class QuestionJuniorScience extends Question {

}
