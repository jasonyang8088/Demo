package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 高中地理
 */
@Entity(name=Constants.TABLE_QUESTION_SENIOR_GEOGRAPHY)
public class QuestionSeniorGeography extends Question {
	
}
