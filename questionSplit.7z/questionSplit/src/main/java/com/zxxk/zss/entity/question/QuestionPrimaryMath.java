package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 小学信息技术
 */
@Entity(name=Constants.TABLE_QUESTION_PRIMARY_MATH)
public class QuestionPrimaryMath extends Question {


}
