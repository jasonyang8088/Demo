package com.zxxk.zss.entity.question;


import javax.persistence.Entity;

import com.zxxk.zss.entity.Question;
import com.zxxk.zss.utils.Constants;

/***
 * 高中信息技术
 */
@Entity(name=Constants.TABLE_QUESTION_SENIOR_INFORMATION)
public class QuestionSeniorInformation extends Question {


}
